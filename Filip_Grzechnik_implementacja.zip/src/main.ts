import { s } from './productions.js';

s('(1.2 * 3) + 5 - (23.4 + 3) ^3; 8 : 3;'.replace(/\s/g, ''));
